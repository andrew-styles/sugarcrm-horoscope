<?php

$app_list_strings['horoscope_sign_list'] = isset($app_list_strings['horoscope_sign_list']) ? $app_list_strings['horoscope_sign_list'] : [];

$app_list_strings['horoscope_sign_list'][''] = '';
$app_list_strings['horoscope_sign_list']['Aries'] = 'Aries';
$app_list_strings['horoscope_sign_list']['Taurus'] = 'Taurus';
$app_list_strings['horoscope_sign_list']['Gemini'] = 'Gemini';
$app_list_strings['horoscope_sign_list']['Cancer'] = 'Cancer';
$app_list_strings['horoscope_sign_list']['Leo'] = 'Leo';
$app_list_strings['horoscope_sign_list']['Virgo'] = 'Virgo';
$app_list_strings['horoscope_sign_list']['Libra'] = 'Libra';
$app_list_strings['horoscope_sign_list']['Scorpio'] = 'Scorpio';
$app_list_strings['horoscope_sign_list']['Sagittarius'] = 'Sagittarius';
$app_list_strings['horoscope_sign_list']['Capricorn'] = 'Capricorn';
$app_list_strings['horoscope_sign_list']['Aquarius'] = 'Aquarius';
$app_list_strings['horoscope_sign_list']['Pisces'] = 'Pisces';